package be.kuleuven.mytomato;

import android.app.Application;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import be.kuleuven.mytomato.database.ToDo;


public class User extends Application {
        private String userName;
        private int userID;
        private String password;
        private int gender;
        private String registerDate;
        private String whats_up;
        private int photo;
        private ArrayList<ToDo> ToDoList;


        private RequestQueue requestQueue;
        private static final String SEARCH_USER_URL="https://studev.groept.be/api/a21pt321/search_user/";
        private static final String UPDATE_USERNAME_URL="https://studev.groept.be/api/a21pt321/update_userName/";
        private static final String UPDATE_PASSWORD_URL="https://studev.groept.be/api/a21pt321/update_password/";
        private static final String UPDATE_PHOTO_URL="https://studev.groept.be/api/a21pt321/update_photo/";
        private static final String UPDATE_WHATSUP_URL="https://studev.groept.be/api/a21pt321/update_whatsUp/";
        private static final String UPDATE_GENDER_URL="https://studev.groept.be/api/a21pt321/update_gender/";
        private static final String SEARCH_TODO_BY_USERID_URL="https://studev.groept.be/api/a21pt321/search_todo_by_userId/";
        private static final String INSERT_HABIT_URL="https://studev.groept.be/api/a21pt321/insert_toDo/";


        public User(){
            ToDoList= new ArrayList<>();
        }

        public void initializing(int ID,String userName, String password,
                                 String registerDate,int photo, int gender, String whats_up){
            this.userName=userName;
            userID=ID;
            this.photo=photo;
            this.password=password;
            this.gender=gender;
            this.whats_up=whats_up;
            this.registerDate=registerDate;
        }

        /*public void update(String name){
            requestQueue= Volley.newRequestQueue(this);
            String searchUserURL=SEARCH_USER_URL+name;
            JsonArrayRequest searchUserRequest=new JsonArrayRequest(Request.Method.GET, searchUserURL, null, response -> {
                JSONObject o;
                try {
                    o = response.getJSONObject(0);
                    int id=o.getInt("id");
                    String userName=(String)o.get("userName");
                    String password=(String)o.get("password");
                    String registerDate=(String)o.get("registerDate");
                    int photo=o.getInt("photo");
                    int gender=o.getInt("gender");
                    String whatsUp= o.getString("whatsUp");
                    initializing(id,userName,password,registerDate,photo,gender,whatsUp);
                }
                catch (JSONException e) {
                    e.printStackTrace();
                }
            }, error -> error.printStackTrace());
            requestQueue.add(searchUserRequest);
        }*/

       public void setUserName(String newUserName){
           requestQueue= Volley.newRequestQueue(this);
           String setUserNameURL=UPDATE_USERNAME_URL+newUserName+"/"+userID;
           StringRequest setUserNameRequest=new StringRequest(Request.Method.GET,setUserNameURL, response -> {
               userName=newUserName;
           }, error -> {
               });
           requestQueue.add(setUserNameRequest);
        }
         public boolean checkPassword(String InputPassword){
             return InputPassword.equals(password);
        }
        public void setPassword(String newPassword){
            requestQueue= Volley.newRequestQueue(this);
            String setURL=UPDATE_PASSWORD_URL+newPassword+"/"+userID;
            StringRequest setRequest=new StringRequest(Request.Method.GET,setURL, response -> {
                password=newPassword;
            }, error -> {
            });
            requestQueue.add(setRequest);
        }
       public void setGender(char newGender){
           requestQueue= Volley.newRequestQueue(this);
           String setURL=UPDATE_GENDER_URL+newGender+"/"+userID;
           StringRequest setRequest=new StringRequest(Request.Method.GET,setURL, response -> {
               gender=newGender;
           }, error -> {
           });
           requestQueue.add(setRequest);
        }

       public void setWhats_up(String newWhats_up){
           requestQueue= Volley.newRequestQueue(this);
           String setURL=UPDATE_WHATSUP_URL+newWhats_up+"/"+userID;
           StringRequest setRequest=new StringRequest(Request.Method.GET,setURL, response -> {
               whats_up=newWhats_up;
           }, error -> {
           });
           requestQueue.add(setRequest);
        }

    public void setPhoto(int newPhoto){
        requestQueue= Volley.newRequestQueue(this);
        String setURL=UPDATE_PHOTO_URL+newPhoto+"/"+userID;
        StringRequest setRequest=new StringRequest(Request.Method.GET,setURL, response -> {
            photo=newPhoto;
        }, error -> {
        });
        requestQueue.add(setRequest);
    }

        public String  getUserName(){return userName;}
        public int getGender(){return gender;}
        public String getWhats_up(){return whats_up;}
        public int getUserID(){return userID;}
        public int getPhoto(){return  photo;}
        public String getPassword(){return password;}
        public String getRegisterDate(){return registerDate;}

        public boolean intToBoolean(int toConvert){
            return toConvert > 0;
        }
        public void downloadToDoList(){
            ToDoList.clear();
            requestQueue= Volley.newRequestQueue(this);
            String searchHabitByUserIDURL=SEARCH_TODO_BY_USERID_URL+userID;
            JsonArrayRequest searchHabitByUserIDRequest=new JsonArrayRequest(Request.Method.GET, searchHabitByUserIDURL, null, response -> {
             for(int i=0;i<response.length();i++){
                 JSONObject o;
                 try{
                     o=response.getJSONObject(i);
                     ToDo todo=new ToDo(o.getInt("imageID"), (String) o.get("name"), (String) o.get("note"),
                             o.getInt("color"), (String) o.get("time"), (String) o.get("ddlDate"),
                             intToBoolean(o.getInt("label1")), intToBoolean(o.getInt("label2")),
                             intToBoolean( o.getInt("label3")), intToBoolean(o.getInt("label4")),
                             o.getInt("year"),o.getInt("month"), o.getInt("day"),
                             o.getInt("hour"), o.getInt("minute"),
                             o.getInt("doneTimes"),o.getInt("timesToDo"),intToBoolean(o.getInt("isDone")));
                     ToDoList.add(todo);
                 }
                 catch (JSONException e){
                     e.printStackTrace();
                 }
             }
             }, Throwable::printStackTrace);
            requestQueue.add(searchHabitByUserIDRequest);
        }

        public String showHabit(){
            String info="";
            for(int i=0;i<ToDoList.size();i++){

                info+=ToDoList.get(i).getName()+"\n";
            }
            return info;
        }

        public int booleanToInt(boolean toConvert){
           if(toConvert)
               return 1;
           else
               return 0;
        }
        //如果该用户已经有该习惯且该习惯未完成，返回false
        public boolean addToDo(ToDo newToDo){
           boolean duplicity=false;
           for(int i=0;i<ToDoList.size();i++){
               if(newToDo.getName().equals(ToDoList.get(i).getName())){
                    duplicity=true;
               }
           }
           if(!duplicity){

               requestQueue= Volley.newRequestQueue(this);
               String insertURL=INSERT_HABIT_URL+userID;
               insertURL+="/"+newToDo.getName();
               insertURL+="/"+newToDo.getNote();
               insertURL+="/"+newToDo.getColor();
               insertURL+="/"+newToDo.getImageID();
               insertURL+="/"+newToDo.getTime();
               insertURL+="/"+newToDo.getDate();
               insertURL+="/"+booleanToInt(newToDo.isLabel1());
               insertURL+="/"+booleanToInt(newToDo.isLabel2());
               insertURL+="/"+booleanToInt(newToDo.isLabel3());
               insertURL+="/"+booleanToInt(newToDo.isLabel4());
               insertURL+="/"+"0";
               insertURL+="/"+newToDo.getTimesToDo();
               insertURL+="/"+"0";
               insertURL+="/"+newToDo.getYear();
               insertURL+="/"+newToDo.getMonth();
               insertURL+="/"+newToDo.getDay();
               insertURL+="/"+newToDo.getHour();
               insertURL+="/"+newToDo.getMinute();

               StringRequest insertRequest=new StringRequest(Request.Method.GET,insertURL, response -> {
                   ToDoList.add(newToDo);
               }, error -> {
               });
               requestQueue.add(insertRequest);
           }
            return duplicity;
        }

        public ArrayList<ToDo> getToDoList(){
            return ToDoList;
        }
    }


