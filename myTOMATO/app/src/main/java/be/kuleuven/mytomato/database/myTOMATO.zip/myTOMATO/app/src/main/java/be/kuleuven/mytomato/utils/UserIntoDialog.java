package be.kuleuven.mytomato.utils;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.KeyboardShortcutGroup;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import be.kuleuven.mytomato.R;

public class UserIntoDialog extends Dialog implements View.OnClickListener {
    EditText input;
    ImageView back;
    Button confirm,cancel;

    public interface OnEnsureListener{
        public void OnEnsure(String input);
    }

    UserIntoDialog.OnEnsureListener onEnsureListener;

    public void setOnEnsureListener(UserIntoDialog.OnEnsureListener onEnsureListener) {
        this.onEnsureListener = onEnsureListener;
    }

    public UserIntoDialog(@NonNull Context context) {
        super(context);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.user_cancel:
                cancel();
                break;
            case R.id.dialog3_back:
                cancel();
                break;
            case R.id.user_confirm:
                String text = input.getText().toString().trim();
                onEnsureListener.OnEnsure(text);
                cancel();
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_user);
        back = findViewById(R.id.dialog3_back);
        input = findViewById(R.id.user_input);
        confirm = findViewById(R.id.user_confirm);
        cancel = findViewById(R.id.user_cancel);
        confirm.setOnClickListener(this);
        cancel.setOnClickListener(this);
    }
}
