package be.kuleuven.mytomato.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import be.kuleuven.mytomato.R;
import be.kuleuven.mytomato.database.ToDo;

public class itemAdapter extends BaseAdapter{
    Context context;
    List<ToDo> mItems;
    LayoutInflater inflater;
    public itemAdapter(Context context, List<ToDo> mItems) {
        this.context = context;
        this.mItems = mItems;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return mItems.size();
    }

    @Override
    public Object getItem(int i) {
        return mItems.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
       viewHolder holder = null;
        if(view==null){
            view = inflater.inflate(R.layout.main_item,viewGroup,false);

            holder=new viewHolder(view);
            view.setTag(holder);
        }
        else{
            holder = (viewHolder)view.getTag();
        }
        ToDo item = mItems.get(i);
        holder.image.setImageResource(item.getImageID());
        holder.name.setText(item.getName());
        holder.note.setText(item.getNote());
        holder.date.setText(item.getDate());
        holder.time.setText(item.getTime());
        //改颜色
        return view;
    }

    class viewHolder{
        ImageView image;
        TextView name,note,time,date;
        public viewHolder(View view){
            image = view.findViewById(R.id.item_image);
            name= view.findViewById(R.id.item_name);
            note = view.findViewById(R.id.item_note);
            date = view.findViewById(R.id.item_ddl);
            time = view.findViewById(R.id.item_ddl_time);
        }
    }
}
