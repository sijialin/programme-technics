package be.kuleuven.mytomato;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.RequestQueue;

import be.kuleuven.mytomato.utils.ChangePasswordDialog;
import be.kuleuven.mytomato.utils.UserIntoDialog;

public class UserActivity extends AppCompatActivity {

    ImageView back, name, password, gender, help,photo,whatsup;
    TextView logout, myname, mypassword, mygender,displayName,displayWhatsup,ID;

    private User user;
    private RequestQueue requestQueue;
    private static final String SEARCH_USER_URL="https://studev.groept.be/api/a21pt321/search_user/";

    String[] genders = {"Unknown","Female","Male"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        initView();

        user=(User)getApplication();
        ID.setText(Integer.toString(user.getUserID()));
        //photoText.setText(Integer.toString(user.getPhoto()));
        myname.setText(user.getUserName());
        displayName.setText(user.getUserName());
        mygender.setText(genders[user.getGender()]);
        String whatsupDisplay = user.getWhats_up();
        if(whatsupDisplay==null) whatsupDisplay = "Be better everyday!";
        displayWhatsup.setText(whatsupDisplay);
    }

    private void initView() {
        back = findViewById(R.id.user_back);
        name = findViewById(R.id.user_intoName);
        password = findViewById(R.id.user_intoPassword);
        gender = findViewById(R.id.user_intoGender);
        help = findViewById(R.id.user_intoQ);
        logout = findViewById(R.id.user_logout);
        myname = findViewById(R.id.user_name);
        mypassword = findViewById(R.id.user_password);
        mygender = findViewById(R.id.user_gender);
        displayName = findViewById(R.id.displayName);
        displayWhatsup = findViewById(R.id.displayWhatsup);
        photo = findViewById(R.id.user_photo);
        whatsup = findViewById(R.id.user_intoWhatsup);
        ID = findViewById(R.id.user_ID);


    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.user_back:
                finish();
                break;
            case R.id.user_intoName:
                showUserDialog();
                break;
            case R.id.user_intoPassword:
                showPasswordDialog();
                break;
            case R.id.user_intoGender:
                showGenderDialog();
                break;
            case R.id.user_intoQ:
                
                break;
            case R.id.user_intoWhatsup:
                showWhatsupDialog();
                break;
            case R.id.user_logout:
                user.initializing(0,null,null,null,0,0,null);
                Intent it1 = new Intent(this, MainActivity.class);
                startActivity(it1);
                break;
        }
    }

    private void showWhatsupDialog() {
    }

    private void showGenderDialog() {
    }

    private void showPasswordDialog() {
        ChangePasswordDialog dialog = new ChangePasswordDialog(this);
        dialog.show();
        dialog.setOnEnsureListener(new ChangePasswordDialog.OnEnsureListener() {
            @Override
            public void OnEnsure(String newpw) {
                //在数据库中改变用户密码
            }
        });
    }

    private void showUserDialog() {
        UserIntoDialog dialog = new UserIntoDialog(this);
        dialog.show();
        dialog.setOnEnsureListener(new UserIntoDialog.OnEnsureListener() {
            @Override
            public void OnEnsure(String input) {
                //更新数据库
                myname.setText(input);
                displayName.setText(input);
            }
        });
    }
}
